# JX Category Products

2.0.3
FIX:
 - fixed an issue during theme installation caused by wrong usage of count()

2.0.2
FIX:
 - removed a restriction of a table entry length that cause an error when a lot of product was added to some of a category block
 - fixed an issue with products duplicating from the previous block to the next blocks

2.0.1
Reworked an algorithm of the selected products parsing to avoid problems with page loading