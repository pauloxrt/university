# JX Blog

0.0.2
FIX: fixed an issue with PHP 7 compatibility(admin part). An error with setMedia conformity