# JX Google Map

v 1.2.5 - fixed an issue with resetting to default settings if another model was unhooked

v 1.2.4 - remover invalid map's style file
        - fixed a mess with hook names during module hook setting and unsetting
        - fixed an issue with map styling when a couple of maps are present in a page

v 1.2.3 - fixed compatibility with Prestashop 1.7.3 in due that Store came to be multilingual